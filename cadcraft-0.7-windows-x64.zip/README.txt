CADCraft Dievartis Preview 0.7 - Windows x64

Run cadcraft.exe after extracting this archive.
Personal fork: https://github.com/Dievartis/cadcraft
Source: bc1bf538012eeb34bb44e06f8fb61259bdc30729

The executable was compiled and supplied by the fork owner.
Licences, source credits and integration reports are included.
Additional optional fallback-font embedding has not been verified.
